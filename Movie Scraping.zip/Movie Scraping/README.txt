This tool was build in order to scrap movies info from imdb website directly from windows cmd.
In order to use this tool you have to do the following:
1. Create a folder and download the movies.py and movies.bat in to it.
2. Please install the following packages in the terminal: requests, beautifulsoup4, webbrowser (pip install package_name)
3. On the bat file (press the right key of the mouse, and choose edit) 
change the first path to your python absolute path, and then change the second path 
to the path of the movie.py file location on your computer
(wherever you put the downloaded file) see example on the attached "batch example file.jpg"
4. Open the cmd and type the location of the bat file and the name of the requested movie, separated by space
5. Done!!!  , a file with the name of the movie will be created in the same folder of movie.bat .